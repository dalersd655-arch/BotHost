import os, asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message

dp = Dispatcher()

@dp.message(CommandStart())
async def start(m: Message):
    await m.answer("Привет! Я работаю на вашем хостинге 🎉")

@dp.message()
async def echo(m: Message):
    await m.answer(m.text or "👍")

async def main():
    print("Bot started", flush=True)
    await dp.start_polling(Bot(os.environ["BOT_TOKEN"]))

asyncio.run(main())
